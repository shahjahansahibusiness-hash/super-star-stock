import { buildPushHTTPRequest } from '@pushforge/builder';

const json = (data,status=200) => new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
const now = () => new Date().toISOString();
const id = () => crypto.randomUUID();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const fromB64 = s => Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4)),c=>c.charCodeAt(0));
async function sha256(s){return b64(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))}
async function hashPassword(password,salt){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:fromB64(salt),iterations:150000,hash:'SHA-256'},key,256);return b64(bits)}
async function newPassword(password){const salt=b64(crypto.getRandomValues(new Uint8Array(16)));return {salt,hash:await hashPassword(password,salt)}}
async function verifyPassword(password,salt,hash){return (await hashPassword(password,salt))===hash}
async function sessionUser(request,env){const h=request.headers.get('Authorization')||'';if(!h.startsWith('Bearer '))return null;const token=h.slice(7);const th=await sha256(token);const r=await env.DB.prepare(`SELECT u.*,o.name outlet_name,o.short_name FROM sessions s JOIN users u ON u.id=s.user_id JOIN outlets o ON o.id=u.outlet_id WHERE s.token_hash=? AND s.expires_at>?`).bind(th,now()).first();return r||null}
async function createSession(env,userId){const raw=b64(crypto.getRandomValues(new Uint8Array(32)));const th=await sha256(raw);const exp=new Date(Date.now()+1000*60*60*24*30).toISOString();await env.DB.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').bind(th,userId,exp).run();return raw}
function outletFrom(u){return {id:u.outlet_id,name:u.outlet_name,short_name:u.short_name}}
async function sendSalePush(env,sale){if(!env.VAPID_PRIVATE_KEY||!env.VAPID_PUBLIC_KEY)return;const subs=await env.DB.prepare('SELECT * FROM push_subscriptions').all();const body=`🛵 SOLD at ${sale.outlet_short_name} — ${sale.model} ${sale.colour} | Engine ${sale.engine_number} | ${money(sale.sale_price)} | ${fmt(sale.sale_date)}`;await Promise.all((subs.results||[]).map(async s=>{try{const req=await buildPushHTTPRequest({privateJWK:JSON.parse(env.VAPID_PRIVATE_KEY),subscription:{endpoint:s.endpoint,keys:{p256dh:s.p256dh,auth:s.auth}},message:{payload:{title:'Super Star Stock',body,icon:'/icon-192.png',badge:'/icon-192.png',url:'/'},adminContact:env.VAPID_SUBJECT||'mailto:admin@example.com',options:{urgency:'high',ttl:86400}}});const res=await fetch(req.endpoint,{method:'POST',headers:req.headers,body:req.body});if(res.status===404||res.status===410)await env.DB.prepare('DELETE FROM push_subscriptions WHERE id=?').bind(s.id).run()}catch(e){console.log('push failed',String(e))}}))}
const money=n=>'Rs '+Number(n||0).toLocaleString('en-PK');
const fmt=d=>d?d.split('-').reverse().join('-'):'';
async function route(request,env,path){
  if(path==='/login'&&request.method==='POST'){
    const b=await request.json();const u=await env.DB.prepare('SELECT u.*,o.name outlet_name,o.short_name FROM users u JOIN outlets o ON o.id=u.outlet_id WHERE u.outlet_id=? AND lower(u.username)=lower(?)').bind(b.outlet,b.username).first();if(!u)return json({error:'Username not found for this outlet'},401);
    if(u.password_hash){if(!b.password||!(await verifyPassword(b.password,u.password_salt,u.password_hash)))return json({error:'Incorrect password'},401)}
    const token=await createSession(env,u);return json({token,user:{id:u.id,username:u.username,display_name:u.display_name},outlet:outletFrom(u)})
  }
  const u=await sessionUser(request,env);if(!u)return json({error:'Not authenticated'},401);
  if(path==='/me')return json({user:{id:u.id,username:u.username,display_name:u.display_name},outlet:outletFrom(u)});
  if(path==='/bootstrap'){
    await env.DB.prepare(`UPDATE credits SET status=CASE WHEN remaining_amount<=0 THEN 'PAID' WHEN due_date < date('now') THEN 'OVERDUE' ELSE 'OPEN' END WHERE outlet_id=?`).bind(u.outlet_id).run();
    const [inv,sales,purchases,credits,customers,models,push]=await Promise.all([
      env.DB.prepare(`SELECT * FROM inventory WHERE outlet_id=? ORDER BY date_added DESC,created_at DESC`).bind(u.outlet_id).all(),
      env.DB.prepare(`SELECT s.*,u.display_name sold_by_name FROM sales s JOIN users u ON u.id=s.sold_by WHERE s.outlet_id=? ORDER BY sale_date DESC,created_at DESC`).bind(u.outlet_id).all(),
      env.DB.prepare(`SELECT * FROM purchases WHERE outlet_id=? ORDER BY date_received DESC,created_at DESC`).bind(u.outlet_id).all(),
      env.DB.prepare(`SELECT c.*,cu.name customer_name,cu.phone customer_phone,cu.address customer_address,s.model,s.colour,s.engine_number,s.chassis_number FROM credits c JOIN customers cu ON cu.id=c.customer_id JOIN sales s ON s.id=c.sale_id WHERE c.outlet_id=? ORDER BY c.created_at DESC`).bind(u.outlet_id).all(),
      env.DB.prepare(`SELECT * FROM customers WHERE outlet_id=? ORDER BY name`).bind(u.outlet_id).all(),
      env.DB.prepare(`SELECT DISTINCT model FROM inventory WHERE outlet_id=? ORDER BY model`).bind(u.outlet_id).all(),
      env.DB.prepare(`SELECT count(*) c FROM push_subscriptions WHERE user_id=?`).bind(u.id).first()
    ]);
    for(const c of credits.results||[]){const ps=await env.DB.prepare(`SELECT * FROM credit_payments WHERE credit_id=? ORDER BY payment_date DESC,created_at DESC`).bind(c.id).all();c.payments=ps.results||[]}
    return json({inventory:inv.results||[],sales:sales.results||[],purchases:purchases.results||[],credits:credits.results||[],customers:customers.results||[],models:(models.results||[]).map(x=>x.model),pushConfigured:!!(env.VAPID_PRIVATE_KEY&&env.VAPID_PUBLIC_KEY),pushEnabled:!!push?.c})
  }
  if(path==='/inventory'&&request.method==='POST'){
    const b=await request.json();if(!b.engine_number||!b.chassis_number||!b.model||!b.colour||!Number.isFinite(Number(b.company_price)))return json({error:'All required fields must be filled'},400);
    try{const iid=id();await env.DB.batch([
      env.DB.prepare(`INSERT INTO inventory(id,outlet_id,engine_number,chassis_number,model,colour,company_price,date_added,status,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)`).bind(iid,u.outlet_id,b.engine_number.trim(),b.chassis_number.trim(),b.model.trim(),b.colour.trim(),Number(b.company_price),b.date_added||new Date().toISOString().slice(0,10),'IN_STOCK',u.id),
      env.DB.prepare(`INSERT INTO purchases(id,outlet_id,inventory_id,date_received,engine_number,chassis_number,model,colour,company_price,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)`).bind(id(),u.outlet_id,iid,b.date_added||new Date().toISOString().slice(0,10),b.engine_number.trim(),b.chassis_number.trim(),b.model.trim(),b.colour.trim(),Number(b.company_price),u.id)
    ]);return json({ok:true})}catch(e){return json({error:String(e).includes('UNIQUE')?'Duplicate engine or chassis number at this outlet':'Could not add stock'},400)}
  }
  if(path==='/sale'&&request.method==='POST'){
    const b=await request.json();const item=await env.DB.prepare(`SELECT * FROM inventory WHERE id=? AND outlet_id=? AND status='IN_STOCK'`).bind(b.inventory_id,u.outlet_id).first();if(!item)return json({error:'That unit is no longer available'},409);if(Number(b.sale_price)<0)return json({error:'Sale price is invalid'},400);
    const sid=id();const profit=Number(b.sale_price)-Number(item.company_price);try{await env.DB.batch([
      env.DB.prepare(`UPDATE inventory SET status='SOLD' WHERE id=? AND status='IN_STOCK'`).bind(item.id),
      env.DB.prepare(`INSERT INTO sales(id,outlet_id,inventory_id,sale_date,sale_price,buyer_name,buyer_phone,model,colour,engine_number,chassis_number,company_price,profit,sold_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(sid,u.outlet_id,item.id,b.sale_date||new Date().toISOString().slice(0,10),Number(b.sale_price),b.buyer_name||null,b.buyer_phone||null,item.model,item.colour,item.engine_number,item.chassis_number,item.company_price,profit,u.id)
    ]);}catch(e){return json({error:'Could not record sale'},400)}
    const sale={id:sid,outlet_short_name:u.short_name,model:item.model,colour:item.colour,engine_number:item.engine_number,sale_price:Number(b.sale_price),sale_date:b.sale_date||new Date().toISOString().slice(0,10)};await sendSalePush(env,sale);return json({ok:true,sale})
  }
  if(path==='/credit'&&request.method==='POST'){
    const b=await request.json();const item=await env.DB.prepare(`SELECT * FROM inventory WHERE id=? AND outlet_id=? AND status='IN_STOCK'`).bind(b.inventory_id,u.outlet_id).first();if(!item)return json({error:'That unit is no longer available'},409);const total=Number(b.total_amount),initial=Number(b.initial_payment||0);if(!b.customer?.name||!b.due_date||total<=0||initial<0||initial>total)return json({error:'Check customer, total, payment and deadline'},400);
    const cid=id(),sid=id(),crid=id();try{await env.DB.batch([
      env.DB.prepare(`INSERT INTO customers(id,outlet_id,name,phone,address) VALUES(?,?,?,?,?)`).bind(cid,u.outlet_id,b.customer.name.trim(),b.customer.phone||null,b.customer.address||null),
      env.DB.prepare(`UPDATE inventory SET status='SOLD' WHERE id=? AND status='IN_STOCK'`).bind(item.id),
      env.DB.prepare(`INSERT INTO sales(id,outlet_id,inventory_id,sale_date,sale_price,buyer_name,buyer_phone,model,colour,engine_number,chassis_number,company_price,profit,sold_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(sid,u.outlet_id,item.id,b.due_date?new Date().toISOString().slice(0,10):new Date().toISOString().slice(0,10),total,b.customer.name,b.customer.phone||null,item.model,item.colour,item.engine_number,item.chassis_number,item.company_price,total-item.company_price,u.id),
      env.DB.prepare(`INSERT INTO credits(id,outlet_id,sale_id,customer_id,total_amount,initial_payment,remaining_amount,due_date,notes,status,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)`).bind(crid,u.outlet_id,sid,cid,total,initial,total-initial,b.due_date,b.notes||null,initial===total?'PAID':'OPEN',u.id)
    ]);if(initial>0)await env.DB.prepare(`INSERT INTO credit_payments(id,outlet_id,credit_id,payment_date,amount,notes,recorded_by) VALUES(?,?,?,?,?,?,?)`).bind(id(),u.outlet_id,crid,new Date().toISOString().slice(0,10),initial,'Initial payment',u.id).run();return json({ok:true})}catch(e){return json({error:'Could not record credit sale: '+e.message},400)}
  }
  if(path==='/credit-payment'&&request.method==='POST'){
    const b=await request.json();const c=await env.DB.prepare(`SELECT * FROM credits WHERE id=? AND outlet_id=?`).bind(b.credit_id,u.outlet_id).first();if(!c)return json({error:'Credit account not found'},404);const amount=Number(b.amount);if(amount<=0||amount>c.remaining_amount)return json({error:'Payment must be within the remaining balance'},400);const remaining=c.remaining_amount-amount;await env.DB.batch([
      env.DB.prepare(`INSERT INTO credit_payments(id,outlet_id,credit_id,payment_date,amount,notes,recorded_by) VALUES(?,?,?,?,?,?,?)`).bind(id(),u.outlet_id,c.id,b.payment_date||new Date().toISOString().slice(0,10),amount,b.notes||null,u.id),
      env.DB.prepare(`UPDATE credits SET remaining_amount=?,status=? WHERE id=?`).bind(remaining,remaining===0?'PAID':(c.due_date<new Date().toISOString().slice(0,10)?'OVERDUE':'OPEN'),c.id)
    ]);return json({ok:true})
  }
  if(path==='/password'&&request.method==='POST'){
    const b=await request.json();if(!b.password||b.password.length<6)return json({error:'Password must be at least 6 characters'},400);const p=await newPassword(b.password);await env.DB.prepare('UPDATE users SET password_salt=?,password_hash=? WHERE id=?').bind(p.salt,p.hash,u.id).run();return json({ok:true})
  }
  if(path==='/reset'&&request.method==='POST'){
    await env.DB.batch([
      env.DB.prepare('DELETE FROM credit_payments WHERE outlet_id=?').bind(u.outlet_id),env.DB.prepare('DELETE FROM credits WHERE outlet_id=?').bind(u.outlet_id),env.DB.prepare('DELETE FROM customers WHERE outlet_id=?').bind(u.outlet_id),env.DB.prepare('DELETE FROM sales WHERE outlet_id=?').bind(u.outlet_id),env.DB.prepare('DELETE FROM purchases WHERE outlet_id=?').bind(u.outlet_id),env.DB.prepare('DELETE FROM inventory WHERE outlet_id=?').bind(u.outlet_id)
    ]);return json({ok:true})
  }
  if(path==='/subscribe'&&request.method==='POST'){
    const b=await request.json();if(!b.endpoint||!b.keys?.p256dh||!b.keys?.auth)return json({error:'Invalid push subscription'},400);await env.DB.prepare(`INSERT INTO push_subscriptions(id,user_id,endpoint,p256dh,auth,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id,p256dh=excluded.p256dh,auth=excluded.auth,updated_at=CURRENT_TIMESTAMP`).bind(id(),u.id,b.endpoint,b.keys.p256dh,b.keys.auth).run();return json({ok:true})
  }
  if(path==='/push-config')return json({publicKey:env.VAPID_PUBLIC_KEY||null});
  if(path==='/notifications'){
    const since=request.url.includes('?')?new URL(request.url).searchParams.get('since'):null;const q=since?`SELECT s.*,o.short_name outlet_short_name FROM sales s JOIN outlets o ON o.id=s.outlet_id WHERE s.created_at>? ORDER BY s.created_at DESC LIMIT 10`:`SELECT s.*,o.short_name outlet_short_name FROM sales s JOIN outlets o ON o.id=s.outlet_id ORDER BY s.created_at DESC LIMIT 1`;const r=since?await env.DB.prepare(q).bind(since).all():await env.DB.prepare(q).all();return json({sales:r.results||[]})
  }
  return json({error:'Not found'},404)
}
export default {async fetch(request,env){const url=new URL(request.url);if(url.pathname.startsWith('/api/')){try{return await route(request,env,url.pathname.slice(4))}catch(e){console.error(e);return json({error:'Server error'},500)}}return env.ASSETS.fetch(request)}};

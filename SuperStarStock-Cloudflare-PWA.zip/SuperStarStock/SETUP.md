# Super Star Stock — Cloudflare setup (simple guide)

## 1. What you are deploying

This is a **PWA (Progressive Web App)**, not an App Store `.ipa`. On iPhone, Safari can install a web app to the Home Screen when the site has a web app manifest and `display: standalone`. iOS Home Screen web apps also support Web Push on supported iOS versions. The app therefore behaves like an app while remaining hosted on your Cloudflare domain.

Architecture:

`iPhone 1` → `Cloudflare Worker` → `Cloudflare D1 database`

`iPhone 2` → `Cloudflare Worker` → `same D1 database`

For sales alerts:

`Worker` → `Web Push (VAPID)` → `Apple/Browser push service` → **both iPhones**

The database is not stored on either iPhone. The phones are clients of the Cloudflare database.

## 2. Create the Cloudflare database

From a computer with Node.js installed:

```bash
cd SuperStarStock
npm install
npx wrangler login
npx wrangler d1 create super-star-stock
```

Cloudflare will return a database ID. Copy it into `wrangler.jsonc`:

```json
"database_id": "PASTE_THE_ID_HERE"
```

Then create all tables and the two initial outlet accounts:

```bash
npx wrangler d1 migrations apply super-star-stock --remote
```

The migration starts inventory completely empty. It only creates the two outlets and the two usernames.

## 3. Push notifications

Push needs a VAPID key pair. Generate it once:

```bash
npx @pushforge/builder vapid
```

You will receive a public key and a private JWK. Put the **public key** in `wrangler.jsonc`:

```json
"vars": {
  "VAPID_PUBLIC_KEY": "YOUR_PUBLIC_KEY"
}
```

Store the private JWK as a Cloudflare secret:

```bash
npx wrangler secret put VAPID_PRIVATE_KEY
```

Paste the complete private JWK JSON when prompted.

Then:

```bash
npx wrangler secret put VAPID_SUBJECT
```

Use something like:

```text
mailto:your-email@example.com
```

Do **not** put the private JWK in the public `wrangler.jsonc` file.

## 4. Deploy

This project uses Cloudflare Workers with static assets. You do not need a separate traditional web server.

```bash
npx wrangler deploy
```

Cloudflare will give you an HTTPS `workers.dev` URL.

You can later attach your own domain from Cloudflare, for example:

`stock.yourdomain.com`

## 5. Install on both iPhones

On each iPhone:

1. Open the HTTPS Cloudflare URL in **Safari**.
2. Choose **Share**.
3. Choose **Add to Home Screen**.
4. Open the new **Super Star Stock** icon from the Home Screen.
5. Choose the correct outlet.
6. Log in.
7. When asked, allow notifications.
8. Repeat on the second iPhone.

Do not use the normal Safari tab as the main operating mode if you want iOS Web Push. Use the Home Screen version.

## 6. Initial accounts

The requested accounts are created with no password:

- Abbasia Town → `Shahjahan`
- Khanpur Road → `Afrasayab`

Because username-only login is intentionally allowed initially, anyone who knows a username could enter before a password is set. **Set a password on both accounts immediately** from Settings → Change password.

Passwords are stored as PBKDF2-derived hashes, not plain text.

## 7. How the database stays online

Every action goes to the Worker API and D1:

- Restock → `inventory` + `purchases`
- Sale → marks the exact unit sold + creates a permanent `sales` record
- Credit sale → sale + customer + credit account + initial payment
- Credit payment → permanent `credit_payments` record + remaining balance update
- Statements → read directly from D1
- Reset → deletes only the selected outlet's business records

If an iPhone is replaced, nothing needs to be restored from the phone. Install the PWA on the new iPhone and log in; the records remain in D1.

## 8. Outlet isolation

Every inventory, purchase, sale, customer, credit and payment record has an `outlet_id`.

The API gets the outlet from the authenticated session and never accepts a user-selected outlet for normal data operations. This prevents Abbasia data from being mixed with Khanpur Road data.

The sale notification is different: it deliberately reads push subscriptions for **both outlets**, because the requirement is for both phones to receive sale alerts.

## 9. Credit workflow

A credit sale records:

- customer name
- phone
- address
- exact scooter/unit
- engine + chassis
- total sale amount
- initial payment
- remaining amount
- deadline
- notes
- sale/profit information

The Credit screen shows the **total amount still recoverable** across outstanding customers.

For each customer you can open the account and record additional payments. Once the remaining balance reaches zero, the account becomes Paid.

If the deadline passes while money remains outstanding, it is shown as Overdue.

## 10. Statements

Sales/Purchase statement:

`Super Star Factory Outlet Abbasia Town Sale Purchase Data Record`

or

`Super Star Factory Outlet Khanpur Road Sale Purchase Data Record`

Credit statement:

`Super Star Factory Outlet Abbasia Town Credit Recovery Statement`

or the Khanpur Road equivalent.

The statement screen supports:

- From date
- To date
- PDF
- Word `.docx`
- Print
- Share

The PDF/Word statement includes the Super Star logo at the top.

## 11. Changing the app

The most important files are:

- `public/main.js` — app screens and workflows
- `public/style.css` — design/theme
- `worker.js` — secure API/database logic
- `migrations/0001_initial.sql` — database schema
- `public/manifest.webmanifest` — iPhone Home Screen configuration
- `public/sw.js` — push notification service worker
- `public/logo.png` / icons — branding

After changing code, deploy again:

```bash
npx wrangler deploy
```

The D1 data is separate from the static app deployment, so deploying a new version does not wipe the database.

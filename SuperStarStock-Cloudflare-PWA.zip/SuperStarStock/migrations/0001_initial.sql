PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS outlets (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  short_name TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  outlet_id TEXT NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
  username TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  password_salt TEXT,
  password_hash TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inventory (
  id TEXT PRIMARY KEY,
  outlet_id TEXT NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
  engine_number TEXT NOT NULL,
  chassis_number TEXT NOT NULL,
  model TEXT NOT NULL,
  colour TEXT NOT NULL,
  company_price INTEGER NOT NULL,
  date_added TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'IN_STOCK' CHECK(status IN ('IN_STOCK','SOLD')),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(outlet_id, engine_number),
  UNIQUE(outlet_id, chassis_number)
);

CREATE TABLE IF NOT EXISTS purchases (
  id TEXT PRIMARY KEY,
  outlet_id TEXT NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
  inventory_id TEXT NOT NULL REFERENCES inventory(id) ON DELETE CASCADE,
  date_received TEXT NOT NULL,
  engine_number TEXT NOT NULL,
  chassis_number TEXT NOT NULL,
  model TEXT NOT NULL,
  colour TEXT NOT NULL,
  company_price INTEGER NOT NULL,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sales (
  id TEXT PRIMARY KEY,
  outlet_id TEXT NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
  inventory_id TEXT NOT NULL REFERENCES inventory(id),
  sale_date TEXT NOT NULL,
  sale_price INTEGER NOT NULL,
  buyer_name TEXT,
  buyer_phone TEXT,
  model TEXT NOT NULL,
  colour TEXT NOT NULL,
  engine_number TEXT NOT NULL,
  chassis_number TEXT NOT NULL,
  company_price INTEGER NOT NULL,
  profit INTEGER NOT NULL,
  sold_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY,
  outlet_id TEXT NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS credits (
  id TEXT PRIMARY KEY,
  outlet_id TEXT NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
  sale_id TEXT NOT NULL UNIQUE REFERENCES sales(id) ON DELETE CASCADE,
  customer_id TEXT NOT NULL REFERENCES customers(id),
  total_amount INTEGER NOT NULL,
  initial_payment INTEGER NOT NULL DEFAULT 0,
  remaining_amount INTEGER NOT NULL,
  due_date TEXT NOT NULL,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','PAID','OVERDUE')),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS credit_payments (
  id TEXT PRIMARY KEY,
  outlet_id TEXT NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
  credit_id TEXT NOT NULL REFERENCES credits(id) ON DELETE CASCADE,
  payment_date TEXT NOT NULL,
  amount INTEGER NOT NULL,
  notes TEXT,
  recorded_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL UNIQUE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_inventory_outlet_status ON inventory(outlet_id, status);
CREATE INDEX IF NOT EXISTS idx_sales_outlet_date ON sales(outlet_id, sale_date);
CREATE INDEX IF NOT EXISTS idx_credits_outlet_status ON credits(outlet_id, status);
CREATE INDEX IF NOT EXISTS idx_credit_payments_credit ON credit_payments(credit_id, payment_date);

INSERT OR IGNORE INTO outlets(id,name,short_name) VALUES
('abbasia','Super Star Factory Outlet — Abbasia Town','Abbasia Town'),
('khanpur','Super Star Factory Outlet — Khanpur Road','Khanpur Road');

INSERT OR IGNORE INTO users(id,outlet_id,username,display_name) VALUES
('user-abbasia','abbasia','Shahjahan','Shahjahan'),
('user-khanpur','khanpur','Afrasayab','Afrasayab');

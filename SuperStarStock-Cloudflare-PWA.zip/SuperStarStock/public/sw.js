self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('push', event => {
  const data = event.data?.json?.() || {};
  const title = data.title || 'Super Star Stock';
  const options = {
    body: data.body || 'New update',
    icon: data.icon || '/icon-192.png',
    badge: '/icon-192.png',
    data: data.url || '/',
    tag: data.tag || 'super-star-stock',
    renotify: true
  };
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const url = event.notification.data || '/';
  event.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(list => {
    for (const client of list) if ('focus' in client) { client.focus(); client.navigate(url); return; }
    return clients.openWindow(url);
  }));
});

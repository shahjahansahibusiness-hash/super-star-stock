# Super Star Stock

Cloudflare Workers + D1 full-stack PWA for Super Star Factory Outlet.

## What is included
- iPhone Home Screen PWA UI with black/gold branding.
- Two isolated outlets and usernames: Shahjahan / Abbasia Town and Afrasayab / Khanpur Road.
- Unit-level inventory with unique engine/chassis numbers.
- Sales, profit, sales history, statements.
- Credit sales, customers, initial payment, due date, remaining receivable, payments and credit statements.
- Cloudflare D1 persistent online database.
- Web Push infrastructure for both phones after VAPID secrets are configured.
- PDF, DOCX, Print and Share statement actions.
- Reset All Stock protected by typed RESET confirmation.

## Important security note
The requested accounts initially have no password. That means anyone who knows the username can enter until a password is set. Set a password on both phones immediately after the first login. The app stores passwords as PBKDF2 hashes, not plaintext.

## Cloudflare deployment
1. Install Node.js 20+.
2. Run `npm install`.
3. Create D1: `npx wrangler d1 create super-star-stock`.
4. Put the returned database id into `wrangler.jsonc`.
5. Apply schema: `npx wrangler d1 migrations apply super-star-stock --remote`.
6. Generate VAPID keys with `npx @pushforge/builder vapid`.
7. Add the VAPID public key to a Worker variable and the private JWK + subject as secrets:
   - `npx wrangler secret put VAPID_PRIVATE_KEY`
   - `npx wrangler secret put VAPID_SUBJECT`
   - set `VAPID_PUBLIC_KEY` as a non-secret var in `wrangler.jsonc` or with the dashboard.
8. `npm run build` then `npx wrangler deploy`.
9. Open the deployed HTTPS URL on each iPhone in Safari. Share → Add to Home Screen. Open the Home Screen app, log in, and allow notifications.

For a custom domain, attach it to the Worker in Cloudflare after deployment.
